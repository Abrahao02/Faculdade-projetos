using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CS2SKINAppWeb.Pages
{
    public class QuemsomosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
